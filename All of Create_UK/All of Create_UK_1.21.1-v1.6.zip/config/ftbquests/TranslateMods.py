import os
import json
import time
import re
from google import genai
from google.genai import types

API_KEY = "AIzaSyCNuqHE4EQboCa-GcJHobyHR-c77HZgUjM"
TARGET_LANG = "Ukrainian"
MODEL_ID = "gemini-3.1-flash-lite-preview"

# Скрипт лежить у config/ftbquests/
SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
BASE_DIR = os.path.dirname(os.path.dirname(SCRIPT_DIR))  # All of Create_UK_1.21.1-v1.6/
RESOURCEPACKS_DIR = os.path.join(BASE_DIR, "resourcepacks", "AOC_UK", "assets")
QUESTS_LANG_DIR = SCRIPT_DIR  # en_us.snbt лежить поруч зі скриптом
HISTORY_FILE = os.path.join(BASE_DIR, "translated_history.log")

client = genai.Client(api_key=API_KEY)

# ─── Утиліти ──────────────────────────────────

def load_history():
    if os.path.exists(HISTORY_FILE):
        with open(HISTORY_FILE, "r", encoding="utf-8") as f:
            return set(line.strip() for line in f)
    return set()

def save_to_history(key):
    with open(HISTORY_FILE, "a", encoding="utf-8") as f:
        f.write(key + "\n")

def contains_cyrillic(text):
    return bool(re.search("[\u0400-\u04ff]", str(text)))

def validate_and_fix_keys(original, translated):
    issues = []
    fixed = {}
    orig_keys = set(original.keys())
    trans_keys = set(translated.keys())
    missing = orig_keys - trans_keys
    extra = trans_keys - orig_keys
    if missing or extra:
        issues.append("  KEY MISMATCH: missing=" + str(len(missing)) + " extra=" + str(len(extra)))
    for key in orig_keys:
        if key in translated:
            fixed[key] = translated[key]
        else:
            fixed[key] = original[key]
            issues.append("  RESTORED: " + key)
    return fixed, issues

def call_api(sys_instr, chunk):
    while True:
        try:
            response = client.models.generate_content(
                model=MODEL_ID,
                contents=json.dumps(chunk, ensure_ascii=False),
                config=types.GenerateContentConfig(
                    system_instruction=sys_instr,
                    response_mime_type="application/json",
                    temperature=0.1
                )
            )
            return json.loads(response.text)
        except Exception as e:
            err = str(e)
            if "429" in err or "503" in err:
                wait = 60 if "429" in err else 15
                print("  Rate limit. Sleeping " + str(wait) + "s...")
                time.sleep(wait)
                continue
            print("  API error: " + err[:150])
            return None

def translate_in_chunks(original, sys_instr, chunk_size=150):
    keys = list(original.keys())
    total = (len(keys) + chunk_size - 1) // chunk_size
    result = {}
    for i in range(0, len(keys), chunk_size):
        chunk_keys = keys[i:i + chunk_size]
        chunk = {k: original[k] for k in chunk_keys}
        n = i // chunk_size + 1
        if total > 1:
            print("  Chunk " + str(n) + "/" + str(total) + "...", end="\r")
        translated = call_api(sys_instr, chunk)
        if translated is None:
            return None
        fixed, issues = validate_and_fix_keys(chunk, translated)
        for issue in issues:
            print(issue)
        result.update(fixed)
        time.sleep(1.2)
    if total > 1:
        print()
    return result

JSON_INSTR = (
    "You are a Minecraft mod localizer. Target language: " + TARGET_LANG + ".\n"
    "RULES:\n"
    "1. Input JSON: KEYS = translation keys, VALUES = English text.\n"
    "2. Translate ONLY VALUES. NEVER change/rename/remove any KEY.\n"
    "3. Do NOT translate: IDs with ':', format codes (&a §b %s %d), commands, URLs.\n"
    "4. Keep Minecraft color codes exactly.\n"
    "5. Return ONLY valid JSON with identical keys."
)

SNBT_INSTR = (
    "You are a Minecraft FTB Quests localizer. Target language: " + TARGET_LANG + ".\n"
    "RULES:\n"
    "1. Input JSON: KEYS = translation identifiers, VALUES = English quest text.\n"
    "2. Translate ONLY VALUES. NEVER change/rename/remove any KEY.\n"
    "3. Do NOT translate: color codes (&e &6 &2 etc.), IDs with ':', commands.\n"
    "4. Keep format codes in exact positions.\n"
    "5. Return ONLY valid JSON with identical keys."
)

# ─── JSON (resourcepacks): en_us.json → uk_ua.json, оригінал видаляється ───

def translate_json_file(src_path, history):
    dst_path = os.path.join(os.path.dirname(src_path), "uk_ua.json")
    rel = os.path.relpath(src_path, BASE_DIR).replace("\\", "/")
    hkey = "json:" + rel
    if hkey in history:
        print("  Skip (history): " + rel)
        return True
    if os.path.exists(dst_path):
        with open(dst_path, "r", encoding="utf-8") as f:
            ex = json.load(f)
        if contains_cyrillic(json.dumps(ex, ensure_ascii=False)):
            print("  Skip (uk_ua.json exists): " + rel)
            save_to_history(hkey)
            return True
    with open(src_path, "r", encoding="utf-8") as f:
        original = json.load(f)
    print("\nJSON: " + rel + " (" + str(len(original)) + " keys)")
    result = translate_in_chunks(original, JSON_INSTR)
    if result is None:
        return False
    with open(dst_path, "w", encoding="utf-8") as f:
        json.dump(result, f, indent=2, ensure_ascii=False)
    os.remove(src_path)
    save_to_history(hkey)
    print("  OK: uk_ua.json saved, en_us.json deleted")
    return True

# ─── SNBT (quests/lang): en_us.snbt → uk_ua.snbt ───

def parse_snbt_lang(text):
    result = {}
    pattern = re.compile(r'^\s*([\w.]+)\s*:\s*"((?:[^"\\]|\\.)*)"\s*$')
    for line in text.splitlines():
        m = pattern.match(line)
        if m:
            key = m.group(1)
            value = m.group(2).replace('\\"', '"').replace("\\n", "\n")
            result[key] = value
    return result

def build_snbt_lang(data):
    lines = ["{"]
    for key, value in data.items():
        escaped = value.replace('"', '\\"').replace("\n", "\\n")
        lines.append("\t" + key + ': "' + escaped + '"')
    lines.append("}")
    return "\n".join(lines) + "\n"

def translate_snbt_file(src_path, history):
    dst_path = os.path.join(os.path.dirname(src_path), "uk_ua.snbt")
    rel = os.path.relpath(src_path, BASE_DIR).replace("\\", "/")
    hkey = "snbt:" + rel
    if hkey in history:
        print("  Skip (history): " + rel)
        return True
    if os.path.exists(dst_path):
        with open(dst_path, "r", encoding="utf-8") as f:
            if contains_cyrillic(f.read()):
                print("  Skip (uk_ua.snbt exists): " + rel)
                save_to_history(hkey)
                return True
    with open(src_path, "r", encoding="utf-8") as f:
        original = parse_snbt_lang(f.read())
    if not original:
        print("  Empty/unrecognized SNBT: " + rel)
        return False
    print("\nSNBT: " + rel + " (" + str(len(original)) + " keys)")
    result = translate_in_chunks(original, SNBT_INSTR)
    if result is None:
        return False
    with open(dst_path, "w", encoding="utf-8") as f:
        f.write(build_snbt_lang(result))
    save_to_history(hkey)
    print("  OK: uk_ua.snbt saved")
    return True

# ─── Main ───

def collect_targets():
    targets = []
    # JSON: шукаємо en_us.json у resourcepacks рекурсивно
    if os.path.isdir(RESOURCEPACKS_DIR):
        for root, dirs, files in os.walk(RESOURCEPACKS_DIR):
            for fname in files:
                if fname == "en_us.json":
                    targets.append(("json", os.path.join(root, fname)))
    # SNBT: en_us.snbt лежить поруч зі скриптом
    src = os.path.join(QUESTS_LANG_DIR, "en_us.snbt")
    if os.path.exists(src):
        targets.append(("snbt", src))
    return targets

def main():
    history = load_history()
    targets = collect_targets()
    j = sum(1 for t in targets if t[0] == "json")
    s = sum(1 for t in targets if t[0] == "snbt")
    print("Localizer | Model: " + MODEL_ID)
    print("  JSON (resourcepacks): " + str(j))
    print("  SNBT (quests/lang):   " + str(s))
    print("  Total: " + str(len(targets)))
    ok = fail = 0
    for item in targets:
        if item[0] == "json":
            r = translate_json_file(item[1], history)
        else:
            r = translate_snbt_file(item[1], history)
        if r:
            ok += 1
        else:
            fail += 1
    print("\nDone: OK=" + str(ok) + " FAIL=" + str(fail))

if __name__ == "__main__":
    main()
